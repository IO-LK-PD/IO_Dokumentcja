function toggle(source) {
    var checkboxes = document.querySelectorAll('input[type="checkbox"]');
    for (var i = 0; i < checkboxes.length; i++) {
        if (checkboxes[i] != source)
            checkboxes[i].checked = source.checked;
    }
}

$(function () {
  $('[data-toggle="popover"]').popover({
    html: true,
    trigger: "hover",
    delay: {
        show: "500",
    },
  });
})

/*
$("#check_all").on("click", function(){
*/
/*        $("input[type=checkbox]").prop('checked', $(this).prop('checked'));*//*

          $("input[type=checkbox]").prop('checked', this.checked);
});
*/

//var header = document.getElementById("nav nav-masthead");
//var btns = header.getElementsByClassName("nav-link");
//for (var i = 0; i < btns.length; i++) {
//    btns[i].addEventListener("click", function() {
//    var current = document.getElementsByClassName("active");
//    current[0].className = current[0].className.replace(" active", "");
//    this.className += " active";
//    });
//}


var isAdvancedUpload = function() {
    var div = document.createElement('div');
    return (('draggable' in div) || ('ondragstart' in div && 'ondrop' in div)) && 'FormData' in window && 'FileReader' in window;
}();

var forms = document.querySelectorAll( '.box' );
Array.prototype.forEach.call( forms, function( form )
{
    var input		 = form.querySelector( 'input[type="file"]' ),
        label		 = form.querySelector( 'label' ),
        errorMsg	 = form.querySelector( '.box__error span' ),
        restart		 = form.querySelectorAll( '.box__restart' ),
        droppedFiles = false,
        showFiles	 = function( files ) {
            label.textContent = files.length > 1 ? ( input.getAttribute( 'data-multiple-caption' ) || '' ).replace( '{count}', files.length ) : files[ 0 ].name;
        };
    var formset = this,
        emptyForm = element.querySelector('.empty-form').firstElementChild,
        formsList = element.querySelector('.forms'),
        initialForms = element.querySelector('[name$=INITIAL_FORM_COUNT]'),
        totalForms = element.querySelector('[name$=TOTAL_FORM_COUNT]'),
        prefix = initialForms.name.replace(/INITIAL_FORM_COUNT$/, '');

        triggerFormSubmit = function() {
            var event = document.createEvent( 'HTMLEvents' );
            event.initEvent( 'submit', true, false );
            form.dispatchEvent( event );
        };

    // letting the server side to know we are going to make an Ajax request
    var ajaxFlag = document.createElement( 'input' );
    ajaxFlag.setAttribute( 'type', 'hidden' );
    ajaxFlag.setAttribute( 'name', 'ajax' );
    ajaxFlag.setAttribute( 'value', 1 );
    form.appendChild( ajaxFlag );

    // automatically submit the form on file select
    input.addEventListener( 'change', ( e ) =>
    {
        const fileList = e.target.files;
        showFiles( fileList );
        triggerFormSubmit();
    });

    // drag&drop files if the feature is available
    if( isAdvancedUpload )
    {
        form.classList.add( 'has-advanced-upload' ); // letting the CSS part to know drag&drop is supported by the browser

        [ 'drag', 'dragstart', 'dragend', 'dragover', 'dragenter', 'dragleave', 'drop' ].forEach( function( event )
        {
            form.addEventListener( event, function( e )
            {
                // preventing the unwanted behaviours
                e.preventDefault();
                e.stopPropagation();
            });
        });
        [ 'dragover', 'dragenter' ].forEach( function( event )
        {
            form.addEventListener( event, function()
            {
                form.classList.add( 'is-dragover' );
            });
        });
        [ 'dragleave', 'dragend', 'drop' ].forEach( function( event )
        {
            form.addEventListener( event, function()
            {
                form.classList.remove( 'is-dragover' );
            });
        });
        form.addEventListener( 'drop', function( e ) {
            droppedFiles = e.dataTransfer.files; // the files that were dropped
            showFiles( droppedFiles );
        });
    }


    // if the form was submitted
    form.addEventListener( 'submit', function( e )
    {
        // preventing the duplicate submissions if the current one is in progress
        if( form.classList.contains( 'is-uploading' ) ) return false;

        form.classList.add( 'is-uploading' );
        form.classList.remove( 'is-error' );

        if( isAdvancedUpload ) // ajax file upload for modern browsers
        {
            e.preventDefault();

            // gathering the form data
            var ajaxData = new FormData( form );
            if( droppedFiles )
            {
                Array.prototype.forEach.call( droppedFiles, function( file )
                {
                    ajaxData.append( input.getAttribute( 'name' ), file );
                    const tempFile = input.getAttribute ( file );
                    var newForm = emptyForm.cloneNode(true);
                    renumberForm(newForm, '__prefix__', totalForms.value);
                    newForm.querySelector('[data-formset-remove-form]').addEventListener('click', removeForm);
                    formsList.insertAdjacentElement('beforeend', newForm);
                    element.dispatchEvent(new CustomEvent('add-form.formset', {
                    detail: {
                        form: newForm,
                        formset: formset
                    }
                    totalForms.value = Number(totalForms.value) + 1;
                });
            }

            // ajax request
            var ajax = new XMLHttpRequest();
            ajax.open( form.getAttribute( 'method' ), form.getAttribute( 'action' ), true );
            ajax.setRequestHeader("X-CSRF-TOKEN", $('meta[name="csrf-token"]').attr('content'));

            ajax.overrideMimeType('text/xml');
            // var formsContainer = document.getElementById("forms-container");

            ajax.onload = function()
            {
                form.classList.remove( 'is-uploading' );
                if( ajax.status >= 200 && ajax.status < 400 )
                {
                    try {
                        var data = ajax.responseText;
                        console.log( data );
                        // form.classList.add( data.success == true ? 'is-success' : 'is-error' );
                        form.classList.add( data )
                        console.log(form.classList);
                    } catch (e) {
                        if( !data ) errorMsg.textContent = data.error;
                    }

                    // formsContainer.appendChild(data);
                    console.log(formsContainer)
                    // ukrycie diva o id dropzona
                    // pobranie diva o id forms container
                    // wrzucenie do nieggo danych ze zmiennej data
                    // if no success -> json -> inny format -> data
                }
                else alert(ajax.status);
            };

            ajax.onerror = function()
            {
                form.classList.remove( 'is-uploading' );
                alert( 'Error. Please, try again!' );
            };

            ajax.send( ajaxData )
            console.log(ajax);
            console.log(Object.getPrototypeOf(ajaxData));
        }
        else // fallback Ajax solution upload for older browsers
        {
            var iframeName	= 'uploadiframe' + new Date().getTime(),
                iframe		= document.createElement( 'iframe' );

                $iframe		= $( '<iframe name="' + iframeName + '" style="display: none;"></iframe>' );

            iframe.setAttribute( 'name', iframeName );
            iframe.style.display = 'none';

            document.body.appendChild( iframe );
            form.setAttribute( 'target', iframeName );

            iframe.addEventListener( 'load', function()
            {
                var data = iframe.contentDocument.body.innerHTML;
                form.classList.remove( 'is-uploading' )
                form.classList.add( data.success == true ? 'is-success' : 'is-error' )
                form.removeAttribute( 'target' );
                if( !data ) errorMsg.textContent = data.error;
                iframe.parentNode.removeChild( iframe );
            });
        }

        function Formset(element) {

            if (!(this instanceof Formset)) {
                return new Formset(element);
            }
            var formset = this;
            var emptyForm = element.querySelector('.empty-form').firstElementChild;
            var formsList = element.querySelector('.forms');

            var initialForms = element.querySelector('[name$=INITIAL_FORM_COUNT]');
            var totalForms = element.querySelector('[name$=TOTAL_FORM_COUNT]');
            var prefix = initialForms.name.replace(/INITIAL_FORM_COUNT$/, '');


            function addForm(event) {
                // Duplicate empty form.
                var newForm = emptyForm.cloneNode(true);
                // Update all references to __prefix__ in the elements names.
                renumberForm(newForm, '__prefix__', totalForms.value);
                // Make it able to delete itself.
                newForm.querySelector('[data-formset-remove-form]').addEventListener('click', removeForm);
                // Append the new form to the formsList.
                formsList.insertAdjacentElement('beforeend', newForm);
                element.dispatchEvent(new CustomEvent('add-form.formset', {
                    detail: {
                        form: newForm,
                        formset: formset
                    }
                }));
            // Update the totalForms.value
                totalForms.value = Number(totalForms.value) + 1;
            }

            function getForm(target) {
                var parent = target.parentElement;
                if (parent == document) {
                    return null;
                }

                if (parent == formsList) {
                    return target;
                }

                return getForm(parent);
            }

            function renumberForm(form, oldValue, newValue) {
                var matchValue = prefix + oldValue.toString()
                var match = new RegExp(matchValue);
                var replace = prefix + newValue.toString();

                ['name', 'id', 'for'].forEach(function(attr) {
                    form.querySelectorAll('[' + attr + '*=' + matchValue + ']').forEach(function(el) {
                    el.setAttribute(attr, el.getAttribute(attr).replace(match, replace));
                    });
                });

                element.dispatchEvent(new CustomEvent('renumber-form.formset', {
                    detail: {
                        form: form,
                        oldValue: oldValue,
                        newValue: newValue,
                        formset: formset
                    }
                }));
            }

            element.querySelector('[data-formset-add-form]').addEventListener('click', addForm);
            element.formset = this;

            element.dispatchEvent(new CustomEvent('init.formset', {
                detail: {
                    formset: this
                }
            }));

            this.addForm = addForm;
        }

        new Formset(document.querySelector('#demo'));
    );


    // restart the form if has a state of error/success
    Array.prototype.forEach.call( restart, function( entry )
    {
        entry.addEventListener( 'click', function( e )
        {
            e.preventDefault();
            form.classList.remove( 'is-error', 'is-success' );
            input.click();
        });
    });

    // Firefox focus bug fix for file input
    input.addEventListener( 'focus', function(){ input.classList.add( 'has-focus' ); });
    input.addEventListener( 'blur', function(){ input.classList.remove( 'has-focus' ); });
})