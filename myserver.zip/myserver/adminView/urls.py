import mptt_urls
from django.urls import path, re_path
from . import views

urlpatterns = [
    path('', views.IndexView.as_view(), name='index'),
    path('all_users/', views.UserListView.as_view(), name='all_users'),
    path('file_explorer/create_folder/', views.FolderCreateView.as_view(), name='folder_create'),
    path('file_explorer/upload_file/', views.FileUploadView.as_view(), name='upload_file'),
    #path('file_explorer/upload_file/create_forms/', views.create_forms, name='create_forms'),
    re_path(r'^file_explorer/(?P<path>.*)', mptt_urls.view(model='adminView.models.FileFolder',
                                                           view='adminView.views.get_folder', slug_field='slug',
                                                           trailing_slash=False), name='file_explorer'),
    # re_path(r'^file_explorer/(?P<path>.*)/(?P<file_slug>[-\w]+)/$', mptt_urls.view(model='adminView.models.FileFolder',
    #                                                                                view='adminView.views.FileDetailView.get_path',
    #                                                                                slug_field='slug',
    #                                                                                trailing_slash=False), name='file_explorer')
]

# TO DO: checking all checkboxes via button not checkbox,
#   dropzone/list files/edit
#   m2m upload,
#   url plikow
#   wyszukiwarka,
#   update,
#   delete,
#   rewizja (zip archive?),

