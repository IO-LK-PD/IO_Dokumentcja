from django.contrib.auth.models import Group, User
from django.db import models
from django.utils.text import slugify
from magic import magic
from mptt.models import MPTTModel, TreeForeignKey

from .custom.validator import FileValidator
from django.urls import reverse
from pathlib import PurePosixPath
from django.core.validators import ProhibitNullCharactersValidator

import django_tables2 as tables


class Category(models.Model):
    name = models.CharField(max_length=50, unique=True, null=True)

    class Meta:
        ordering = ['name']
        verbose_name = 'category'
        verbose_name_plural = 'categories'

    def __str__(self):
        return self.name


class FileFolder(MPTTModel):
    slug = models.SlugField(max_length=50, null=True)
    name = models.CharField(max_length=50, null=True, verbose_name='nazwa')
    group = models.ManyToManyField(Group, blank=True)
    parent = TreeForeignKey('self', null=True, blank=True, related_name='children',
                            on_delete=models.CASCADE)
    views = models.PositiveIntegerField('number of page views', default=0)

    class MPTTMeta:
        order_insertion_by = ['slug']
        verbose_name = 'folder'
        verbose_name_plural = 'foldery'

    class Meta:
        unique_together = ['slug', 'parent']
        # constraints = models.UniqueConstraint(fields=['slug', 'parent'], name='unique_folder')

    def __str__(self):
        return self.name or ''

    def save(self, *args, **kwargs):
        self.set_name()
        return super().save(*args, **kwargs)

    def set_name(self):
        if not self.slug:
            self.slug = slugify(self.name)

    def get_absolute_url(self):
        return reverse('file_explorer', kwargs={'path': self.get_path()})

    def get_all_products(self):
        return self.get_descendants

    def get_all_groups(self):
        return ",\n".join([g.name for g in self.group.all()])

    groups = property(get_all_groups)


class FileItem(models.Model):
    name = models.CharField(max_length=200, null=True, verbose_name='nazwa')
    slug = models.SlugField(null=True)
    category = models.ForeignKey(Category, on_delete=models.CASCADE, null=True, verbose_name='kategoria',
                                 blank=True, related_name='files')
    created_at = models.DateTimeField(auto_now_add=True, null=True, verbose_name='data utworzenia')
    update_at = models.DateTimeField(auto_now=True, null=True, verbose_name='')

    parent = models.ManyToManyField(FileFolder, related_name='files')
    owner = models.ForeignKey(User, on_delete=models.CASCADE, null=True)

    validate_file = FileValidator(max_size=1024 * 10000, content_types=('application/pdf', 'text/plain',
                                                                        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                                                                        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'))
    file = models.FileField(verbose_name='plik', upload_to='files', validators=[validate_file])
    mime_type = models.CharField(max_length=100, null=True)

    def __str__(self):
        return str(self.name)

    def save(self, *args, **kwargs):
        self.set_name()
        self.set_slug()
        return super().save(*args, **kwargs)

    def set_name(self):
        self.name = PurePosixPath(self.file.name).stem
        ProhibitNullCharactersValidator(self.name)

    def set_slug(self):
        self.slug = self.name

    def set_mime_type(self, file):
        if not self.mime_type:
            initial_pos = file.tell()
            file.seek(0)
            mime_type = magic.from_buffer(file.read(2048), mime=True)
            file.seek(initial_pos)
            self.mime_type = mime_type

    # def get_absolute_url(self):
    #     return reverse('file_explorer', kwargs={'path': self.parent.get_path()})

    class Meta:
        ordering = ['-created_at']
        # constraints = models.UniqueConstraint(fields=['name', 'parent'], name='unique_file')


# class FileArchive(models.Model):
#     name = models.CharField(max_length=50, null=True, verbose_name='nazwa')
#     parent = models.ForeignKey(FileItem, null=True, related_name='archive', on_delete=models.CASCADE)
#     created_at = models.DateTimeField(auto_now_add=True, null=True, verbose_name='data utworzenia')
#
#     validate_file = FileValidator(max_size=1024 * 10000, content_types=('application/pdf', 'text/plain',
#                                                                         'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
#                                                                         'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'))
#     file = models.FileField(verbose_name='plik', upload_to='files', validators=[validate_file])
#     mime_type = models.CharField(max_length=100, null=True)


class UserTable(tables.Table):
    class Meta:
        model = User
        template_name = 'django_tables2/bootstrap4.html'
        fields = ('id', 'username', 'groups', 'date_joined', 'last_login', 'is_active', 'is_superuser', 'is_staff')
