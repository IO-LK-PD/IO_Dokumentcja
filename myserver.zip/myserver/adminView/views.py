from django.http import HttpResponseRedirect, HttpResponse
from django.urls import reverse_lazy

from .models import UserTable, FileFolder, FileItem
from .forms import FileUploadForm, FolderCreateForm, FileUploadFormSet
from django.views.generic import TemplateView, DetailView
from django.views.generic.edit import CreateView, FormView

from django.contrib.auth.models import User
from django.shortcuts import render


from django_tables2 import SingleTableView


class IndexView(TemplateView):
    template_name = 'index.html'


class FolderCreateView(CreateView):
    model = FileFolder
    form_class = FolderCreateForm
    template_name = 'adminView/filefolder_form.html'


# def get_path(request, instance)
class FormsetCreateView(FormView):
    template_name = "adminView/create_forms.html"

    def get(self, *args, **kwargs):
        formset = FileUploadFormSet(queryset=FileItem)
        return self.render_to_response({'file_formset': formset})

    def post(self, request, *args, **kwargs):
        if request.method == 'POST':
            instances = FileUploadFormSet(self.request.POST, self.request.FILES)
            # files = request.FILES.getlist('file')
            if instances.is_valid():
                instances.save(commit=False)
                for instance in instances:
                    file = instance.cleaned_data.get('file')
                    FileItem(file=file)
                    instance.save()
                    instance.save_m2m()
            else:
                instances = FileUploadFormSet()
            return render(request, 'adminView/create_forms.html', {'formsets': instances})
        else:
            return HttpResponse('<h1>There is no POST data.</h1>')


def get_folder(request, path, instance):
    if instance:
        instance.views += 1
        instance.save()

    return render(
        request,
        'adminView/file_explorer.html',
        {
            'folders': [],
            'instance': instance,
            'children': instance.get_children() if instance else FileFolder.objects.root_nodes()
        }
    )


# class FileDetailView(DetailView):
#     model = FileItem
#     template_name = 'adminView/file_detail.html'
#     context_object_name = 'file'
    #
    # def get_path(self, request, path, instance):
    #     file_instance = FileItem.objects.get(parent=self.instance.parent, )


class FileUploadView(FormView):
    model = FileItem
    form_class = FileUploadForm
    template_name = 'adminView/create_file.html'
    success_url = reverse_lazy('index')

    def form_valid(self, form, **kwargs):
        context = self.get_context_data(**kwargs)
        context['form'] = form
        super().form_valid(form)
        return HttpResponseRedirect(self.get_success_url())

    def form_invalid(self, form, **kwargs):
        context = self.get_context_data(**kwargs)
        context['form'] = form
        return self.render_to_response(context)

    def post(self, request, *args, **kwargs):
        form = FileUploadForm(self.request.POST, self.request.FILES)
        files = request.FILES.getlist('file')
        if form.is_valid():
            form = form.save(commit=False)
            form.upload_file(form, files)
            form.save_m2m()
            return self.form_valid(form, **kwargs)
        else:
            return self.form_invalid(form, **kwargs)


class UserListView(SingleTableView):
    model = User
    table_class = UserTable
    template_name = 'adminView/all_users.html'
    context_object_name = 'user_list'
