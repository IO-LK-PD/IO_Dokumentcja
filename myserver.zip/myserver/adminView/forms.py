from .models import FileItem, FileFolder
from django.forms import ModelForm, ClearableFileInput,  modelformset_factory


class FolderCreateForm(ModelForm):
    class Meta:
        model = FileFolder
        fields = ('name', 'group', 'parent')


class FileUploadForm(ModelForm):
    class Meta:
        model = FileItem
        fields = ('category', 'file', 'parent')

        widgets = {
            'file': ClearableFileInput(attrs={'multiple': True})
        }

    def __init__(self, *args, **kwargs):
        file_to_form = kwargs.pop()

    def upload_file(self, form, files):
        file_instance = form.save(commit=False)
        parents = self.cleaned_data.get('parent')

        for file in files:
            file_instance.save()
            file_instance.parent.add(parents)
            file_instance.file = file
            # file_instance.parent.set(parents)
            file_instance.set_mime_type(file)
            file_instance.save()
        form.save_m2m()
    # def upload_file(self, file):
    #     parents = self.cleaned_data.get('parent')
    #     file_instance = FileItem(file=file, parent=parents)
    #     file_instance.set_mime_type(file)
    #     file_instance.save()


FileUploadFormSet = modelformset_factory(FileItem, form=FileUploadForm, fields=('category', 'file', 'parent'))
