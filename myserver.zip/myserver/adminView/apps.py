from django.apps import AppConfig


class AdminViewConfig(AppConfig):
    name = 'adminView'
