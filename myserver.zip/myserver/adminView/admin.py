from django.contrib import admin
from .models import FileFolder, FileItem, Category


class CategoryAdmin(admin.ModelAdmin):
    model = Category
    fields = ['name', ]

    def get_queryset(self, request):
        queryset = super().get_queryset(request)
        queryset = queryset.prefetch_related('files')
        return queryset


admin.site.register(Category, CategoryAdmin)


# class FileItemAdmin(admin.StackedInline):
#     model = FileItem


class FileFolderAdmin(admin.ModelAdmin):
    model = FileFolder
    fields = ['name', 'group', 'parent']
    list_display = ('name', 'groups', 'parent')

    # inlines = [FileItemAdmin, ]


admin.site.register(FileFolder, FileFolderAdmin)

admin.site.site_title = 'Elogic Viewer administration'
admin.site.site_header = 'Elogic Viewer admin'
admin.site.index_title = 'Elogic Viewer administration'

# Register your models here.
